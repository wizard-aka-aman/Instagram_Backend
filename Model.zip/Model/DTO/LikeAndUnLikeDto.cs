﻿namespace Instagram.Model.DTO
{
    public class LikeAndUnLikeDto
    {
        public string postUsername { get; set; }
        public string likedBy { get; set; }
        public int postId { get; set; } 

    }
}
