﻿namespace Instagram.Model.DTO
{
    public class ReactionDto
    {
        public int messageid { get; set; }
        public string? reaction { get; set; }
    }
}
