﻿namespace Instagram.Model.DTO
{
    public class VideoDto
    {
        public IFormFile file { get; set; }

        public string username { get; set; }
        public string description { get; set; }

    }
}
