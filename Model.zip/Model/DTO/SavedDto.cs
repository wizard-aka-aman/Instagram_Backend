﻿namespace Instagram.Model.DTO
{
    public class SavedDto
    {
        public int PostId { get; set; }
        public string UserName { get; set; }
    }
}
