﻿namespace Instagram.Model.DTO
{
    public class RecentMessageDto
    {
        public string SenderUsername { get; set; }
        public string ReceiverUsername { get; set; }
        public string Message { get; set; }
    }
}
