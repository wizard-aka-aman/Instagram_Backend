﻿namespace Instagram.Model.DTO
{
    public class AuthDto
    {
        public string email { get; set; }
    }
}
