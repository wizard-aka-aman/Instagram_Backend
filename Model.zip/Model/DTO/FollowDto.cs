﻿namespace Instagram.Model.DTO
{
    public class FollowDto
    {
        public string followerUsername { get; set; }
        public string followingUsername { get; set; }
    }
}
