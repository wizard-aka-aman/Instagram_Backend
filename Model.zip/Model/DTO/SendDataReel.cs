﻿namespace Instagram.Model.DTO
{
    public class SendDataReel
    {
        public string Publicid { get; set; }
        public string LikedBy { get; set; }
    }
}
