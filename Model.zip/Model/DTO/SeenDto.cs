﻿namespace Instagram.Model.DTO
{
    public class SeenDto
    {
        public int StoryId { get; set; }
        public string SeenByUsername { get; set; }
    }
}
