﻿namespace Instagram.Model.DTO
{
    public class StoryDto
    {
        public string Username { get; set; }
        public IFormFile imageFile { get; set; }
    }
}
