﻿namespace Instagram.Model.DTO
{
    public class LikeDto
    {
        public string UserName { get; set; }
        public string ProfilePicture { get; set; }
        public DateTime LikedAt { get; set; }
    }
}
