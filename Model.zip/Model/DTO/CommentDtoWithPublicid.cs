﻿namespace Instagram.Model.DTO
{
    public class CommentDtoWithPublicid
    {
        public string CommentText { get; set; }
        public string UserName { get; set; }
        public string publicid { get; set; }
    }
}
