﻿namespace Instagram.Model.DTO
{
    public class SavedReelDto
    {
        public string publicid { get; set; }
        public string UserName { get; set; }
    }
}
